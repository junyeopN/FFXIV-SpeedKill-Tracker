﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace FFXIV_Speedkill_Tracker
{
    public class HPCheckPointDataTable: CheckPointDataTable
    {
        private int _bossTotalHP = -1;

        private List<TrackerHP> _worldRecordCheckPointHPs = null;

        public HPCheckPointDataTable(StreamReader dataFileReader) : base(dataFileReader)
        {
            DataType = HP_DATATYPE;

            _bossTotalHP = Int32.Parse(dataFileReader.ReadLine());

            _worldRecordCheckPointHPs = FindWorldRecordCheckPointHPs(dataFileReader);
            WorldRecordClearTime = new TrackerTime(dataFileReader.ReadLine(), false);
        }

        private List<TrackerHP> FindWorldRecordCheckPointHPs(StreamReader dataFileReader)
        {
            List<TrackerHP> worldRecordHPList = new List<TrackerHP>();

            for (int i = 0; i < Count - 1; i++)
            {
                int totalDamageDone = Int32.Parse(dataFileReader.ReadLine());
                worldRecordHPList.Add(new TrackerHP(_bossTotalHP, totalDamageDone, false));
            }

            return worldRecordHPList;
        }

        public List<TrackerHP> WorldRecordCheckPointHPs
        {
            get => _worldRecordCheckPointHPs;
        }

        public int BossTotalHP
        {
            get => _bossTotalHP;
        }
    }
}
