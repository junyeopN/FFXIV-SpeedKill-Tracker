﻿using System;
using System.IO;
using System.Reflection;

namespace FFXIV_Speedkill_Tracker
{
    class CheckPointDataTableFactory
    {
        static public readonly String DLL_FOLDER_DIRECTORY = Path.GetDirectoryName(Uri.UnescapeDataString(new System.Uri(Assembly.GetExecutingAssembly().CodeBase).AbsolutePath));
        static public readonly String ZONE_DATA_FILE_NAME = DLL_FOLDER_DIRECTORY + "\\Plugins\\FFXIV_Speedkill_Tracker\\FFXIV_Speedkill_Tracker\\ZoneData.txt";

        static public readonly String TIME_CHECKPOINT_DATA_TYPE = "TimeCheckPoints";
        static public readonly String HP_CHECKPOINT_DATA_TYPE = "HPCheckPoints";

        static public CheckPointDataTable createCheckPointDataTable(String zoneName)
        {
            CheckPointDataTable zoneSpeedRunData = null;
            StreamReader dataFileReader = new StreamReader(ZONE_DATA_FILE_NAME);

            zoneSpeedRunData = GetZoneSpeedRunData(zoneName, dataFileReader);

            dataFileReader.Close();



            return zoneSpeedRunData;
        }

        static private CheckPointDataTable GetZoneSpeedRunData(String zoneName, StreamReader dataFileReader)
        {
            if (FindCurrentZone(zoneName, dataFileReader))
            {

                String checkPointDataType = FindCheckPointDataType(dataFileReader);

                return makeNewCheckPointDataTable(checkPointDataType, dataFileReader);
            }
            else
            {
                return null;
            }
        }

        static private Boolean FindCurrentZone(String zoneName, StreamReader dataFileReader)
        {
            while (dataFileReader.Peek() >= 0)
            {
                String currentLine = dataFileReader.ReadLine();

                if (currentLine.Equals(zoneName))
                {
                    return true;
                }
            }

            return false;
        }

        static private String FindCheckPointDataType(StreamReader dataFileReader)
        {
            return dataFileReader.ReadLine();
        }

        static private CheckPointDataTable makeNewCheckPointDataTable(String checkPointDataType, StreamReader dataFileReader)
        {
            if (checkPointDataType.Equals(TIME_CHECKPOINT_DATA_TYPE))
            { 
                return new TimeCheckPointDataTable(dataFileReader);
            }
            else
            {
                return new HPCheckPointDataTable(dataFileReader);
            }
        }
    }
}
