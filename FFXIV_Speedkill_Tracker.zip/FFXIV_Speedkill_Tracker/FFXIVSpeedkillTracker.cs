﻿using Advanced_Combat_Tracker;
using System;
using System.Windows.Forms;
using System.Drawing;

namespace FFXIV_Speedkill_Tracker
{
    public class FFXIVSpeedkillTracker : IActPluginV1
    {

        public static readonly int TIME_DATATYPE = 0;
        public static readonly int HP_DATATYPE = 1;

        private TrackerPage trackerPage = null;
        private Boolean trackerOpen = false;

        private StartTrackerButton startTrackerButton = null;
        private RaidZoneTitleTextBox raidZoneTitleTextBox = null;

        private EncounterData currentFightData = null;

        private TimeSpan duration = new TimeSpan(0);
        private int totalDamageDone = -1;

        private SpeedRunTrackerTable speedRunTrackerTable;
        private CheckPointDataTable checkPointDataTable = null;


        int currentPhase = 0;


        public void InitPlugin(TabPage pluginScreenSpace, Label pluginStatusText)
        {
            InitStartTrackerButton();

            pluginScreenSpace.Controls.Add(startTrackerButton);

            AddEventHandlers(); 
        }

        private void AddEventHandlers()
        {
            ActGlobals.oFormActMain.OnCombatStart += new CombatToggleEventDelegate(SpeedKillTrackerOnCombatStartEventHandler);
            ActGlobals.oFormActMain.OnCombatEnd += new CombatToggleEventDelegate(SpeedKillTrackerOnCombatEndEventHandler);
            ActGlobals.oFormActMain.OnLogLineRead += new LogLineEventDelegate(SpeedKillTrackerOnLogLineReadEventHandler);
        }

        private void InitStartTrackerButton() 
        {
            startTrackerButton = new StartTrackerButton();
            startTrackerButton.Click += new EventHandler(StartTrackerButtonEvent);
        }

        private void StartTrackerButtonEvent(Object sender, EventArgs e)
        {
            if(!trackerOpen)
            {
                InitTracker();
            }
            else
            {
                DeInitTracker();
            }

            startTrackerButton.ChangeText();

            trackerOpen = !trackerOpen;
        }

        void InitTracker()
        {
            trackerPage = new TrackerPage();

            AddRaidZoneTitleTextBox();
            AddSpeedRunTrackerTable();

            trackerPage.Show();
        }


        private void AddRaidZoneTitleTextBox() {
            raidZoneTitleTextBox = new RaidZoneTitleTextBox();

            trackerPage.Controls.Add(raidZoneTitleTextBox);
        }

        void AddSpeedRunTrackerTable() {
            speedRunTrackerTable = new SpeedRunTrackerTable();

            trackerPage.Controls.Add(speedRunTrackerTable);
        }


        void DeInitTracker()
        {
            trackerPage.Hide();
            trackerPage = null;
        }


        void SpeedKillTrackerOnCombatStartEventHandler(bool isImport, CombatToggleEventArgs encounterInfo)
        {
            currentFightData = encounterInfo.encounter;

            try
            {
                LoadFightCheckpoints();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);  
            }
        }

        private void LoadFightCheckpoints()
        {
            String zoneName = ActGlobals.oFormActMain.CurrentZone;


            checkPointDataTable = CheckPointDataTableFactory.createCheckPointDataTable(zoneName);


            if (checkPointDataTable.DataType == TIME_DATATYPE)
            {
                speedRunTrackerTable.UpdateCheckPointDataCells((TimeCheckPointDataTable) checkPointDataTable);
            }
            else
            {
                speedRunTrackerTable.UpdateCheckPointDataCells((HPCheckPointDataTable) checkPointDataTable);
            }
        }


        void SpeedKillTrackerOnCombatEndEventHandler(bool isImport, CombatToggleEventArgs encounterInfo)
        {
            currentFightData = null;
            currentPhase = 0;

            try 
            {
                speedRunTrackerTable.Reset();          
            }
            catch(Exception e) 
            {
                Console.WriteLine(e.Message); 
            } 
        }

        void SpeedKillTrackerOnLogLineReadEventHandler(bool isImport, LogLineEventArgs logInfo)
        {
            try
            {
                String logLine = logInfo.logLine;

                if (currentFightData != null)
                {
                    GetCurrentRunData();

                }

                UpdateCurrentRunDataToTracker();
                
                if (CheckPointDetected(logLine))
                {
                    UpdateCurrentRunWorldRecordRunDifferenceToTracker(); 
                    currentPhase++;
                }

            } catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        private void GetCurrentRunData()
        {
            duration = currentFightData.Duration;
            totalDamageDone = (int)currentFightData.Damage;
        }


        private void UpdateCurrentRunDataToTracker()
        {
            if (checkPointDataTable.DataType == TIME_DATATYPE)
            {
                speedRunTrackerTable.UpdateCurrentRunData(currentPhase, duration);
            }
            else
            {
                int bossTotalHP = ((HPCheckPointDataTable)checkPointDataTable).BossTotalHP;

                speedRunTrackerTable.UpdateCurrentRunData(currentPhase, bossTotalHP, totalDamageDone);
            }
        }

        private Boolean CheckPointDetected(String logLine)
        {
            return checkPointDataTable.CheckPointEventStrings[currentPhase].IsMatch(logLine);
        }


        private void UpdateCurrentRunWorldRecordRunDifferenceToTracker()
        {
            if (isCleared())    
            {
                speedRunTrackerTable.UpdateCurrentRunWorldRecordDifference(currentPhase, CalculateCurrentRunWorldRecordRunClearTimeDifference());
            }
            else if (checkPointDataTable.DataType == TIME_DATATYPE)
            {
                speedRunTrackerTable.UpdateCurrentRunWorldRecordDifference(currentPhase, CalculateCurrentRunWorldRecordRunCheckPointTimeDifference());
            }
            else
            {
                speedRunTrackerTable.UpdateCurrentRunWorldRecordDifference(currentPhase, CalculateCurrentRunWorldRecordRunCheckPointHPDifference());
            }
        }

        private Boolean isCleared()
        {
            return (currentPhase == (checkPointDataTable.Count - 1));
        }

        private TrackerTime CalculateCurrentRunWorldRecordRunClearTimeDifference()
        {
            TrackerTime currentRunClearTime = new TrackerTime(TimeFormatter.Format(duration), false);
            TrackerTime worldRecordClearTime = checkPointDataTable.WorldRecordClearTime;

            return currentRunClearTime.Difference(worldRecordClearTime);
        }
        private TrackerTime CalculateCurrentRunWorldRecordRunCheckPointTimeDifference()
        {
            TrackerTime currentRunTrackerTime = new TrackerTime(TimeFormatter.Format(duration), false);
            TrackerTime worldRecordRunTrackerTime = ((TimeCheckPointDataTable)checkPointDataTable).WorldRecordCheckPointDurations[currentPhase];


            return currentRunTrackerTime.Difference(worldRecordRunTrackerTime);
        }

        private TrackerHP CalculateCurrentRunWorldRecordRunCheckPointHPDifference()
        {
            HPCheckPointDataTable hpCheckPointDataTable = (HPCheckPointDataTable)checkPointDataTable;
            int bossTotalHP = hpCheckPointDataTable.BossTotalHP;


            TrackerHP currentRunCheckPointHP = new TrackerHP(bossTotalHP, totalDamageDone, false);
            TrackerHP worldRecordCheckPointHP = hpCheckPointDataTable.WorldRecordCheckPointHPs[currentPhase];

            return currentRunCheckPointHP.Difference(worldRecordCheckPointHP);      
        }




        public void DeInitPlugin()
        {
            this.trackerPage = null;
            this.currentFightData = null;

            duration = new TimeSpan(0);
        }
    }
}
