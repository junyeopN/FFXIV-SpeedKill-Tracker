﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.IO;

namespace FFXIV_Speedkill_Tracker
{
    public class CheckPointDataTable
    {
        public static readonly int TIME_DATATYPE = 0;
        public static readonly int HP_DATATYPE = 1;

        private int _count = -1;
        private int _dataType = -1;

        private List<String> _checkPointNames = null;
        private List<Regex> _checkPointEventStrings = null;
        
        private TrackerTime _worldRecordClearTime = null;

        public CheckPointDataTable(StreamReader dataFileReader)
        {
            _count = FindCount(dataFileReader);

            _checkPointNames = FindCheckPointNames(dataFileReader);
            _checkPointEventStrings = FindCheckPointEventStrings(dataFileReader);
        }


        public int Count
        {
            get => _count;
            set
            {
                _count = value;
            }
        }

        public TrackerTime WorldRecordClearTime
        {
            get => _worldRecordClearTime;
            set
            {
                _worldRecordClearTime = value;
            }
        }

        public int DataType
        {
            get => _dataType;
            set
            {
                _dataType = value;
            }
        }

        public List<String> CheckPointNames
        {
            get => _checkPointNames;
            set
            {
                _checkPointNames = value;
            }
        }


        public List<Regex> CheckPointEventStrings
        {
            get => _checkPointEventStrings;
            set
            {
                _checkPointEventStrings = value;
            }
        }


        private int FindCount(StreamReader dataFileReader)
        {
            return Int32.Parse(dataFileReader.ReadLine());
        }

        private List<String> FindCheckPointNames(StreamReader dataFileReader)
        {
            List<String> checkPointNames = new List<String>();

            for (int i = 0; i < Count; i++)
            {
                checkPointNames.Add(dataFileReader.ReadLine());
            }

            return checkPointNames;
        }

        private List<Regex> FindCheckPointEventStrings(StreamReader dataFileReader)
        {
            List<Regex> checkPointEventStrings = new List<Regex>();

            for (int i = 0; i < Count; i++)
            {
                checkPointEventStrings.Add(new Regex(dataFileReader.ReadLine()));
            }

            return checkPointEventStrings;
        }

    }
}

