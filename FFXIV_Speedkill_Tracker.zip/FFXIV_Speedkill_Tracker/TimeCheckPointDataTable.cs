﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FFXIV_Speedkill_Tracker
{
    public class TimeCheckPointDataTable : CheckPointDataTable
    {
        private List<TrackerTime> _worldRecordCheckPointDurations = null;

        public TimeCheckPointDataTable(StreamReader dataFileReader) : base(dataFileReader)
        {
             DataType = TIME_DATATYPE;
            
             _worldRecordCheckPointDurations = FindWorldRecordCheckPointDurations(dataFileReader);
             WorldRecordClearTime = new TrackerTime(dataFileReader.ReadLine(), false);
        }

        private List<TrackerTime> FindWorldRecordCheckPointDurations(StreamReader dataFileReader)
        {
            List<TrackerTime> worldRecordDurationList = new List<TrackerTime>();

            for (int i = 0; i < Count - 1; i++)
            {
                worldRecordDurationList.Add(new TrackerTime(dataFileReader.ReadLine(), false));
            }

            return worldRecordDurationList;
        }

        public List<TrackerTime> WorldRecordCheckPointDurations {
            get => _worldRecordCheckPointDurations;
        }
    }
}
